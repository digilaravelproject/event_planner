<?php

namespace Tests\Feature;

use App\Models\Admin;
use App\Models\AdminNotification;
use App\Models\AiSetting;
use App\Models\EventRequirementQuestion;
use App\Models\LandingContent;
use App\Models\Page;
use App\Models\User;
use App\Models\UserEventPlan;
use App\Modules\DynamicVendors\Models\DynamicVendor;
use App\Services\OpenRouterService;
use Database\Seeders\AdminModulesSeeder;
use Database\Seeders\EventRequirementQuestionSeeder;
use Database\Seeders\StandardSubscriptionPlansSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class AdminModulesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(AdminModulesSeeder::class);
        $admin = Admin::create(['name' => 'Module Admin', 'email' => 'modules@example.com', 'password' => 'password']);
        $this->actingAs($admin, 'admin');
    }

    public function test_all_new_admin_module_pages_render(): void
    {
        $this->assertFalse(Route::has('admin.feedback.index'));
        foreach (['admin.vendor-analytics.index', 'admin.ai.manage', 'admin.event-questions.index', 'admin.notifications.index', 'admin.pages.index', 'admin.transactions.index'] as $route) {
            $this->get(route($route))->assertOk();
        }

        foreach (array_keys(LandingContent::TYPES) as $type) {
            $this->get(route('admin.landing-content.index', $type))->assertOk();
        }
    }

    public function test_transaction_filters_stay_on_one_row_and_standard_plans_are_seeded(): void
    {
        $this->seed(StandardSubscriptionPlansSeeder::class);

        $this->get(route('admin.transactions.index'))
            ->assertOk()
            ->assertSee('md:flex-row', false);

        $this->assertDatabaseHas('subscriptions', ['name' => 'free', 'interval' => 'free', 'price' => 0]);
        $this->assertDatabaseHas('subscriptions', ['name' => '3-monthly', 'interval' => 'three_months']);
        $this->assertDatabaseHas('subscriptions', ['name' => '6-monthly', 'interval' => 'six_months']);
        $this->assertDatabaseHas('subscriptions', ['name' => 'yearly', 'interval' => 'yearly']);
    }

    public function test_admin_dashboard_uses_current_platform_records(): void
    {
        $user = User::factory()->create(['name' => 'Dashboard Couple']);
        UserEventPlan::create([
            'user_id' => $user->id,
            'title' => 'Dashboard Wedding Plan',
            'category' => 'wedding',
            'guest_count' => 250,
            'answers' => ['wedding_budget' => 30],
            'requirement_prompt' => 'prompt',
            'summary' => ['title' => 'Dashboard Wedding Plan', 'total_cost' => 3000000, 'costing' => []],
            'total_cost' => 3000000,
            'status' => 'completed',
        ]);
        $this->createDynamicVendor('Dashboard Caterer', [
            ['key' => 'service_area', 'label' => 'Service Area', 'type' => 'dropdown', 'value' => 'Mumbai'],
        ]);
        $this->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee('Live platform overview')
            ->assertSee('Dashboard Wedding Plan')
            ->assertSee(number_format(User::count()))
            ->assertDontSee('2,453')
            ->assertDontSee('14.8L');
    }

    public function test_admin_can_manage_database_backed_landing_content(): void
    {
        $this->post(route('admin.landing-content.store', 'how-it-works'), [
            'title' => 'Share event details',
            'body' => 'Tell us your budget and guest count.',
            'eyebrow' => 'Two minutes',
            'footer' => 'Guided Input',
            'display_order' => 1,
            'status' => 1,
        ])->assertRedirect(route('admin.landing-content.index', 'how-it-works'));

        $item = LandingContent::firstOrFail();
        $this->get(route('home'))->assertOk()->assertSee('Share event details')->assertSee('Tell us your budget and guest count.');
        $this->put(route('admin.landing-content.update', ['how-it-works', $item]), [
            'title' => 'Share your celebration details',
            'body' => 'Updated landing content.',
            'display_order' => 2,
            'status' => 1,
        ])->assertRedirect();
        $this->assertDatabaseHas('landing_contents', ['id' => $item->id, 'title' => 'Share your celebration details']);
        $this->delete(route('admin.landing-content.destroy', ['how-it-works', $item]))->assertRedirect();
        $this->assertDatabaseMissing('landing_contents', ['id' => $item->id]);
    }

    public function test_openrouter_configuration_and_chat_client_use_the_selected_model_and_prompt(): void
    {
        $this->get(route('admin.ai.manage'))->assertOk()->assertSee('OpenRouter Configuration')->assertDontSee('OpenAI API Key');

        AiSetting::setValue('openrouter_api_key', Crypt::encryptString('test-key'));
        AiSetting::setValue('openrouter_model', 'openrouter/auto');
        AiSetting::setValue('openrouter_prompt_template', 'Use only supplied vendor data.');
        Http::fake(['openrouter.ai/api/v1/chat/completions' => Http::response(['choices' => [['message' => ['content' => 'ok']]]])]);

        app(OpenRouterService::class)->chat([['role' => 'user', 'content' => 'Plan my event.']]);

        Http::assertSent(fn ($request) => $request->url() === 'https://openrouter.ai/api/v1/chat/completions'
            && $request['model'] === 'openrouter/auto'
            && data_get($request->data(), 'messages.0.content') === 'Use only supplied vendor data.');
    }

    public function test_question_resource_validates_and_persists(): void
    {
        $this->post(route('admin.event-questions.store'), [
            'question' => 'Which colours?', 'question_code' => 'colours', 'question_type' => 'checkbox',
            'options_text' => "Red\nBlue", 'display_order' => 99, 'is_required' => 1, 'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));
        $this->assertDatabaseHas('event_requirement_questions', ['question_code' => 'colours']);
    }

    public function test_question_can_map_selected_values_from_dynamic_vendor_attributes(): void
    {
        $this->createDynamicVendor('Silver Hall', [
            ['key' => 'area', 'label' => 'Area', 'type' => 'dropdown', 'value' => 'Pune', 'images' => ['dynamic-vendors/areas/pune.jpg']],
            ['key' => 'parking', 'label' => 'Parking', 'type' => 'boolean', 'value' => true],
        ]);
        $this->createDynamicVendor('Gold Hall', [
            ['key' => 'area', 'label' => 'Area', 'type' => 'dropdown', 'value' => 'Mumbai'],
            ['key' => 'parking', 'label' => 'Parking', 'type' => 'boolean', 'value' => false],
        ]);

        $this->get(route('admin.event-questions.create'))
            ->assertOk()
            ->assertSee('Dynamic vendor mapping')
            ->assertSee('Pune')
            ->assertSee('Mumbai')
            ->assertSee('Silver Hall')
            ->assertSee('Gold Hall');

        $this->post(route('admin.event-questions.store'), [
            'question' => 'Which area do you prefer?',
            'question_code' => 'preferred_vendor_area',
            'question_type' => 'checkbox',
            'vendor_attribute_key' => 'area',
            'vendor_attribute_values' => ['Pune', 'Mumbai'],
            'vendor_attribute_images' => ['dynamic-vendors/areas/pune.jpg'],
            'display_order' => 50,
            'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));

        $question = EventRequirementQuestion::where('question_code', 'preferred_vendor_area')->firstOrFail();
        $this->assertSame('area', $question->vendor_attribute_key);
        $this->assertSame('Area', $question->vendor_attribute_label);
        $this->assertSame(['Pune', 'Mumbai'], $question->vendor_attribute_values);
        $this->assertSame(['Pune', 'Mumbai'], $question->options);
        $this->assertSame(['dynamic-vendors/areas/pune.jpg'], $question->vendor_attribute_images);

        $this->get(route('admin.event-questions.show', $question))
            ->assertOk()
            ->assertSee('Question Overview')
            ->assertSee('Which area do you prefer?')
            ->assertSee('Pune')
            ->assertSee('Mumbai');
    }

    public function test_question_mapping_rejects_a_value_not_present_in_vendor_data(): void
    {
        $this->createDynamicVendor('Silver Hall', [
            ['key' => 'area', 'label' => 'Area', 'type' => 'dropdown', 'value' => 'Pune'],
        ]);

        $this->post(route('admin.event-questions.store'), [
            'question' => 'Which area?',
            'question_code' => 'invalid_area',
            'question_type' => 'checkbox',
            'vendor_attribute_key' => 'area',
            'vendor_attribute_values' => ['Unknown'],
            'display_order' => 51,
            'status' => 1,
        ])->assertSessionHasErrors('vendor_attribute_values');

        $this->assertDatabaseMissing('event_requirement_questions', ['question_code' => 'invalid_area']);
    }

    public function test_question_options_can_be_edited_and_keep_their_own_images(): void
    {
        Storage::fake('public');

        $this->post(route('admin.event-questions.store'), [
            'question' => 'Choose a celebration style',
            'question_code' => 'celebration_style',
            'question_type' => 'radio',
            'category_options' => [
                ['name' => 'Garden Celebration', 'subtitle' => 'Fresh outdoor celebration', 'icon' => 'fa-solid fa-leaf', 'image' => UploadedFile::fake()->image('garden.jpg')],
                ['name' => 'Royal Ballroom', 'subtitle' => 'Elegant indoor celebration', 'icon' => 'fa-solid fa-crown', 'image' => UploadedFile::fake()->image('ballroom.jpg')],
            ],
            'display_order' => 4,
            'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));

        $question = EventRequirementQuestion::where('question_code', 'celebration_style')->firstOrFail();
        $this->assertSame(['Garden Celebration', 'Royal Ballroom'], $question->options);
        $this->assertSame('Fresh outdoor celebration', data_get($question->option_metadata, 'Garden Celebration.subtitle'));
        $this->assertSame('fa-solid fa-leaf', data_get($question->option_metadata, 'Garden Celebration.icon'));
        $this->assertCount(2, $question->option_images);
        Storage::disk('public')->assertExists($question->option_images[0]);
        Storage::disk('public')->assertExists($question->option_images[1]);

        $this->put(route('admin.event-questions.update', $question), [
            'question' => 'Choose your celebration style',
            'question_code' => 'celebration_style',
            'question_type' => 'radio',
            'category_options' => [
                ['name' => 'Intimate Garden', 'subtitle' => 'A private garden gathering', 'icon' => 'fa-solid fa-leaf', 'existing_image' => $question->option_images[0]],
                ['name' => 'Royal Ballroom', 'subtitle' => 'Elegant indoor celebration', 'icon' => 'fa-solid fa-crown', 'existing_image' => $question->option_images[1]],
                ['name' => 'Beach Sunset', 'subtitle' => 'A sunset by the sea', 'icon' => 'fa-solid fa-star'],
            ],
            'display_order' => 4,
            'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));

        $question->refresh();
        $this->assertSame(['Intimate Garden', 'Royal Ballroom', 'Beach Sunset'], $question->options);
        $this->assertSame([$question->option_images[0], $question->option_images[1], null], $question->option_images);
        $this->assertSame('A private garden gathering', data_get($question->option_metadata, 'Intimate Garden.subtitle'));
    }

    public function test_mapped_question_accepts_a_custom_user_facing_label_without_losing_mapping(): void
    {
        $this->createDynamicVendor('Mapped Venue', [
            ['key' => 'area', 'label' => 'Area', 'type' => 'dropdown', 'value' => 'Pune'],
        ]);

        $this->post(route('admin.event-questions.store'), [
            'question' => 'Choose an area',
            'question_code' => 'mapped_area_label',
            'question_type' => 'radio',
            'vendor_attribute_key' => 'area',
            'vendor_attribute_values' => ['Pune'],
            'category_options' => [['name' => 'Pune & nearby']],
            'display_order' => 8,
            'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));

        $question = EventRequirementQuestion::where('question_code', 'mapped_area_label')->firstOrFail();
        $this->assertSame(['Pune'], $question->vendor_attribute_values);
        $this->assertSame(['Pune & nearby'], $question->options);
        $this->assertSame(['Pune'], $question->option_vendor_values);
    }

    public function test_food_question_saves_category_and_per_person_cost_for_menu_items(): void
    {
        $this->createDynamicVendor('Wedding Caterer', [
            ['key' => 'menu_card_items', 'label' => 'Menu Card Items', 'type' => 'multi_select', 'value' => ['Paneer Tikka', 'Gulab Jamun']],
        ]);

        $question = EventRequirementQuestion::where('question_code', 'food_type')->firstOrFail();

        $this->put(route('admin.event-questions.update', $question), [
            'question' => 'Which dishes would you like?',
            'question_code' => 'food_type',
            'question_type' => 'checkbox',
            'vendor_attribute_key' => 'menu_card_items',
            'vendor_attribute_values' => ['Paneer Tikka', 'Gulab Jamun'],
            'option_metadata_values' => ['Paneer Tikka', 'Gulab Jamun'],
            'option_metadata_categories' => ['Starters', 'Desserts'],
            'option_metadata_costs' => ['125.50', '60'],
            'display_order' => 5,
            'status' => 1,
        ])->assertRedirect(route('admin.event-questions.index'));

        $question->refresh();
        $this->assertSame('Starters', data_get($question->option_metadata, 'Paneer Tikka.category'));
        $this->assertSame(125.5, data_get($question->option_metadata, 'Paneer Tikka.cost'));

        $this->get(route('ai-planner'))
            ->assertOk()
            ->assertSee('Paneer Tikka')
            ->assertSee('Starters')
            ->assertSee('125.5');
    }

    public function test_question_data_can_be_freshly_rebuilt_from_current_dynamic_vendors(): void
    {
        EventRequirementQuestion::create([
            'question' => 'Legacy question', 'question_code' => 'legacy', 'question_type' => 'textbox',
            'display_order' => 1, 'status' => true,
        ]);
        $this->createDynamicVendor('Silver Hall', [
            ['key' => 'area', 'label' => 'Area', 'type' => 'dropdown', 'value' => 'Pune'],
            ['key' => 'parking', 'label' => 'Parking', 'type' => 'boolean', 'value' => true],
        ]);

        $this->seed(EventRequirementQuestionSeeder::class);

        $this->assertDatabaseMissing('event_requirement_questions', ['question_code' => 'legacy']);
        $this->assertDatabaseHas('event_requirement_questions', ['question_code' => 'wedding_budget', 'question_type' => 'number']);
        $this->assertDatabaseHas('event_requirement_questions', ['question_code' => 'guest_capacity', 'is_required' => true]);
        $this->assertDatabaseHas('event_requirement_questions', ['question_code' => 'decoration_type', 'vendor_attribute_key' => 'decoration_type']);
        $this->assertDatabaseHas('event_requirement_questions', ['question_code' => 'event_category', 'display_order' => 1]);
        $this->assertDatabaseCount('event_requirement_questions', 8);
    }

    public function test_notification_creation_syncs_recipients_using_the_correct_pivot_keys(): void
    {
        $users = User::factory()->count(2)->create();

        $this->post(route('admin.notifications.store'), [
            'title' => 'Service update',
            'message' => 'The platform will be updated tonight.',
            'notification_type' => 'information',
            'recipient_scope' => 'all',
            'status' => 'sent',
        ])->assertRedirect();

        $notification = AdminNotification::firstOrFail();
        $this->assertSame(2, $notification->users()->count());
        foreach ($users as $user) {
            $this->assertDatabaseHas('notification_users', ['notification_id' => $notification->id, 'user_id' => $user->id]);
            $this->assertTrue($user->adminNotifications()->whereKey($notification->id)->exists());
        }
    }

    public function test_vendor_inventory_totals_are_not_reduced_by_activity_period(): void
    {
        $active = $this->createDynamicVendor('Established Active Venue', []);
        $inactive = $this->createDynamicVendor('Established Inactive Venue', []);
        $inactive->update(['status' => 'inactive']);
        DynamicVendor::whereKey([$active->id, $inactive->id])->update(['created_at' => now()->subMonths(3)]);

        $response = $this->get(route('admin.vendor-analytics.index', ['period' => 'month']))->assertOk();
        $cards = $response->viewData('cards');

        $this->assertSame(1, $cards['active_vendors']);
        $this->assertSame(1, $cards['inactive_vendors']);
        $this->assertSame(1, $cards['total_categories']);
        $this->assertSame(0, $cards['period_vendors']);
    }

    public function test_admin_can_create_update_view_and_delete_a_sanitized_page(): void
    {
        $this->post(route('admin.pages.store'), [
            'title' => 'About Our Events',
            'slug' => 'about-events',
            'description' => '<h2 onclick="alert(1)">Welcome</h2><p>Plan with us.</p><script>alert(1)</script><a href="javascript:alert(1)">Bad link</a>',
            'status' => 1,
        ])->assertRedirect();

        $page = Page::firstOrFail();
        $this->assertStringContainsString('<h2>Welcome</h2>', $page->description);
        $this->assertStringNotContainsString('onclick', $page->description);
        $this->assertStringNotContainsString('<script', $page->description);
        $this->assertStringNotContainsString('javascript:', $page->description);

        $this->get(route('admin.pages.show', $page))->assertOk()->assertSee('Plan with us.');
        $this->put(route('admin.pages.update', $page), [
            'title' => 'About Our Celebrations',
            'slug' => 'about-celebrations',
            'description' => '<p>Updated content.</p>',
        ])->assertRedirect();
        $this->assertDatabaseHas('pages', ['id' => $page->id, 'slug' => 'about-celebrations', 'status' => false]);

        $this->delete(route('admin.pages.destroy', $page))->assertRedirect(route('admin.pages.index'));
        $this->assertDatabaseMissing('pages', ['id' => $page->id]);
    }

    public function test_removed_planner_and_prompt_dependencies_are_absent(): void
    {
        foreach (['areas', 'budget_rules', 'cities', 'event_plans', 'master_registries', 'states', 'subareas', 'system_masters', 'ai_prompts'] as $table) {
            $this->assertFalse(Schema::hasTable($table), "The {$table} table should not exist.");
        }

        $this->assertFalse(Route::has('admin.ai-prompts.index'));
        $this->assertFalse(Route::has('user.wizard'));
        $this->get(route('admin.ai.manage'))->assertOk()->assertDontSee('Default Enabled Prompt');
    }

    private function createDynamicVendor(string $name, array $attributes): DynamicVendor
    {
        return DynamicVendor::create([
            'vendor_json' => [
                'schema_version' => 1,
                'identity' => ['name' => $name, 'category' => 'Venue'],
                'attributes' => $attributes,
                'media' => ['images' => []],
                'seo' => [],
            ],
            'status' => 'active',
        ]);
    }
}
