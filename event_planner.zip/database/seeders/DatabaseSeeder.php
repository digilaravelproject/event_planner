<?php

namespace Database\Seeders;

use App\Models\User;
use App\Modules\DynamicVendors\Database\Seeders\DynamicVendorSeeder;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        User::factory()->create([
            'name' => 'Test User',
            'email' => 'test@example.com',
        ]);

        $this->call(AdminSeeder::class);
        $this->call(DynamicVendorSeeder::class);
        $this->call(AdminModulesSeeder::class);
        $this->call(AdminContentSeeder::class);
    }
}
