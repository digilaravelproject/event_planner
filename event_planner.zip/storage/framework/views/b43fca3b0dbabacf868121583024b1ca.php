<?php if(!empty($availability)): ?>
<section id="vendor-availability" class="rounded-3xl border border-rose-100 bg-white p-6 sm:p-8 shadow-lg">
    <span class="text-xs font-bold uppercase tracking-widest text-[#850625]">Check before you book</span>
    <h2 class="mt-2 text-3xl font-bold font-serif-luxury text-slate-950">Vendor availability</h2>
    <p class="mt-2 text-sm leading-relaxed text-slate-600">Checked against the latest saved vendor records for <?php echo e($plan->answers['event_date'] ?? 'your event date (not set)'); ?><?php echo e(!empty($plan->answers['event_time']) ? ' at '.$plan->answers['event_time'] : ''); ?>. This is not a booking confirmation. Saved plan prices below remain unchanged until you generate a new plan.</p>
    <?php if($errors->any()): ?>
        <div role="alert" class="mt-4 rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-900"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><p><?php echo e($error); ?></p><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('user.plans.regenerate', $plan)); ?>" class="mt-5 space-y-4" x-data="{ submitting: false }" @submit="submitting = true">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $availability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $check): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="rounded-2xl border border-slate-200 p-4 sm:p-5">
                <div class="flex flex-wrap items-center justify-between gap-2">
                    <div><h3 class="font-bold text-slate-900"><?php echo e($check['name']); ?></h3><p class="text-xs text-slate-500"><?php echo e($check['category']); ?></p></div>
                    <span class="rounded-full px-3 py-1 text-xs font-bold <?php echo e($check['status'] === 'unavailable' ? 'bg-rose-100 text-rose-800' : ($check['status'] === 'available' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900')); ?>"><?php echo e($check['status'] === 'unavailable' ? 'Unavailable' : ($check['status'] === 'available' ? 'Available per saved schedule' : 'Needs confirmation')); ?></span>
                </div>
                <ul class="mt-3 list-disc space-y-1 pl-5 text-sm text-slate-600"><?php $__currentLoopData = $check['messages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($message); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                <?php if($check['alternatives']): ?>
                    <label for="replace-<?php echo e($key); ?>" class="mt-4 block text-xs font-bold text-slate-700">Choose another vendor</label>
                    <select id="replace-<?php echo e($key); ?>" name="replacements[<?php echo e($key); ?>]" class="mt-2 w-full rounded-xl border border-slate-300 bg-white p-3 text-sm text-slate-800">
                        <option value="">Keep this selection for now</option>
                        <?php $__currentLoopData = $check['alternatives']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($alternative['id']); ?>" <?php if((string) old('replacements.'.$key) === (string) $alternative['id']): echo 'selected'; endif; ?>><?php echo e($alternative['name']); ?> — <?php echo e($alternative['status'] === 'available' ? 'Available per saved schedule' : 'Needs confirmation'); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                <?php else: ?>
                    <p class="mt-3 text-sm text-slate-500">No suitable alternative is listed for these requirements. Contact the vendor, or start a new plan with a different date, area or service selection.</p>
                <?php endif; ?>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(collect($availability)->contains(fn ($check) => !empty($check['alternatives']))): ?>
            <p class="text-xs leading-relaxed text-slate-500">Your answers are retained. Only vendors without a known conflict are listed; those marked “Needs confirmation” still require a direct availability check. Catering replacements must support the selected menu or package. The new plan uses current saved prices.</p>
            <button type="submit" :disabled="submitting" class="w-full rounded-xl bg-[#850625] px-5 py-4 text-sm font-bold text-white shadow-lg disabled:opacity-60 sm:w-auto" x-text="submitting ? 'Generating your new plan…' : 'Generate new plan with selected vendors'">Generate new plan with selected vendors</button>
        <?php endif; ?>
    </form>
</section>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\event_planner\resources\views/ai-planner/partials/vendor-availability.blade.php ENDPATH**/ ?>