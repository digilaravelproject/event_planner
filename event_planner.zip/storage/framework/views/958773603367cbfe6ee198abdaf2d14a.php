<footer id="site-footer" class="w-full relative bg-gradient-to-br from-[#FFFDF9] via-white to-[#FAF7F2] py-12 md:py-16 px-4 sm:px-8 md:px-12 lg:px-16 border-t border-rose-200/80 shadow-2xl shadow-rose-950/[0.05] overflow-hidden scroll-mt-24">
    <!-- Full-bleed Ambient Corner Glows/Shades (Ref Image 1 style with Light Colors) -->
    <div class="absolute -top-24 -left-24 w-[500px] h-[500px] bg-gradient-to-br from-rose-200/50 via-amber-100/40 to-transparent rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute -bottom-24 -right-24 w-[500px] h-[500px] bg-gradient-to-tl from-rose-200/60 via-rose-100/30 to-transparent rounded-full blur-3xl pointer-events-none"></div>
    <div class="absolute top-1/2 right-1/3 -translate-y-1/2 w-96 h-96 bg-amber-100/30 rounded-full blur-3xl pointer-events-none"></div>

    <div class="max-w-[1600px] mx-auto relative z-10 space-y-12">
        <!-- TOP CTA / NEWSLETTER SECTION (Ref Image 2 Top Section) -->
        <div class="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center border-b border-rose-100/80 pb-12">
            <!-- Left: Any query form -->
            <div id="query-form" class="lg:col-span-4 space-y-4 scroll-mt-28">
                <h2 class="text-slate-900 text-2xl md:text-3xl lg:text-4xl font-extrabold font-serif-luxury leading-tight">
                    Have <span class="text-[#850625]">any query?</span>
                </h2>
                <p class="text-slate-600 text-xs md:text-sm max-w-sm leading-relaxed font-medium">
                    Share your details and question. Our team will reply to your email and user panel.
                </p>
                <?php if(session('query_success')): ?><div class="rounded-xl bg-emerald-50 border border-emerald-200 p-3 text-xs font-bold text-emerald-700"><?php echo e(session('query_success')); ?></div><?php endif; ?>
                <form action="<?php echo e(route('queries.store')); ?>" method="POST" class="grid grid-cols-2 gap-2.5 pt-2 max-w-md"><?php echo csrf_field(); ?>
                    <input name="name" value="<?php echo e(old('name', auth()->user()?->name)); ?>" placeholder="Your name" required class="bg-white border border-rose-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#850625]">
                    <input name="email" type="email" value="<?php echo e(old('email', auth()->user()?->email)); ?>" placeholder="Email address" required class="bg-white border border-rose-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#850625]">
                    <input name="phone" value="<?php echo e(old('phone', auth()->user()?->mobile_number)); ?>" placeholder="Phone number" class="bg-white border border-rose-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#850625]">
                    <input name="subject" value="<?php echo e(old('subject')); ?>" placeholder="Subject" required class="bg-white border border-rose-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#850625]">
                    <textarea name="message" rows="3" placeholder="Write your query" required class="col-span-2 bg-white border border-rose-200 rounded-xl px-3.5 py-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#850625]"><?php echo e(old('message')); ?></textarea>
                    <button type="submit" class="bg-[#850625] hover:bg-[#6b041e] text-white text-xs md:text-sm font-bold px-5 py-2.5 rounded-xl shadow-md shadow-[#850625]/20 hover:shadow-lg transition-all flex items-center justify-center gap-2 shrink-0">
                        <span>Submit Query</span>
                        <i class="fa-solid fa-arrow-right text-xs"></i>
                    </button>
                </form>
            </div>

            <!-- Right: Trio Tilted Indian Wedding Photo Cards (Col 8 - Fills All Width) -->
            <div class="lg:col-span-8 grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-5 items-center pt-4 lg:pt-0">
                <!-- Card 1: Indian Royal Bridal Lehenga -->
                <div class="relative group w-full">
                    <!-- Tilted Decorative Backdrop Card -->
                    <div class="absolute inset-0 bg-gradient-to-tr from-[#850625] to-[#D4AF37] rounded-2xl transform -rotate-3 group-hover:-rotate-1 transition-transform duration-300 opacity-30 blur-xs"></div>
                    
                    <!-- Image Container -->
                    <div class="relative bg-white p-2 rounded-2xl border-4 border-white shadow-xl shadow-rose-950/10 transform rotate-2 group-hover:rotate-0 transition-all duration-300 overflow-hidden">
                        <img src="https://images.pexels.com/photos/14666125/pexels-photo-14666125.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Indian Royal Bridal Lehenga" class="w-full h-40 object-cover rounded-xl">
                        <div class="p-2 flex items-center justify-between text-[11px] font-semibold text-slate-700">
                            <span class="flex items-center gap-1 text-[#850625] font-bold">
                                <i class="fa-solid fa-gem text-[#D4AF37]"></i> Royal Lehengas
                            </span>
                            <span class="text-slate-400 font-medium">Jaipur</span>
                        </div>
                    </div>
                </div>

                <!-- Card 2: Royal Varmala Jaimala Ceremony -->
                <div class="relative group w-full">
                    <!-- Tilted Decorative Backdrop Card -->
                    <div class="absolute inset-0 bg-gradient-to-tr from-[#850625] to-[#D4AF37] rounded-2xl transform rotate-3 group-hover:rotate-1 transition-transform duration-300 opacity-30 blur-xs"></div>
                    
                    <!-- Image Container -->
                    <div class="relative bg-white p-2 rounded-2xl border-4 border-white shadow-xl shadow-rose-950/10 transform -rotate-2 group-hover:rotate-0 transition-all duration-300 overflow-hidden">
                        <img src="https://images.pexels.com/photos/1444442/pexels-photo-1444442.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Royal Varmala Jaimala Ceremony" class="w-full h-40 object-cover rounded-xl">
                        <div class="p-2 flex items-center justify-between text-[11px] font-semibold text-slate-700">
                            <span class="flex items-center gap-1 text-[#850625] font-bold">
                                <i class="fa-solid fa-crown text-[#D4AF37]"></i> Royal Varmala
                            </span>
                            <span class="text-slate-400 font-medium">Jodhpur</span>
                        </div>
                    </div>
                </div>

                <!-- Card 3: Grand Mandap Floral Decor -->
                <div class="relative group w-full">
                    <!-- Tilted Decorative Backdrop Card -->
                    <div class="absolute inset-0 bg-gradient-to-tr from-[#850625] to-[#D4AF37] rounded-2xl transform -rotate-2 group-hover:rotate-0 transition-transform duration-300 opacity-30 blur-xs"></div>
                    
                    <!-- Image Container -->
                    <div class="relative bg-white p-2 rounded-2xl border-4 border-white shadow-xl shadow-rose-950/10 transform rotate-3 group-hover:rotate-0 transition-all duration-300 overflow-hidden">
                        <img src="https://images.pexels.com/photos/2291462/pexels-photo-2291462.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Grand Mandap Floral Decor" class="w-full h-40 object-cover rounded-xl">
                        <div class="p-2 flex items-center justify-between text-[11px] font-semibold text-slate-700">
                            <span class="flex items-center gap-1 text-[#850625] font-bold">
                                <i class="fa-solid fa-sparkles text-[#D4AF37]"></i> Grand Mandaps
                            </span>
                            <span class="text-slate-400 font-medium">Udaipur</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- MIDDLE NAVIGATION LINKS (Ref Image 2 Middle Section) -->
        <div class="grid grid-cols-1 md:grid-cols-12 gap-8 lg:gap-10 border-b border-rose-100/80 pb-12">
            <!-- Column 1: Brand Info (4 Cols) -->
            <div class="md:col-span-4 space-y-4">
                <div class="flex items-center space-x-2.5">
                    <span class="bg-[#850625] text-white w-9 h-9 rounded-xl flex items-center justify-center font-bold text-lg shadow-xs">
                        <i class="fa-solid fa-gem text-xs text-[#D4AF37]"></i>
                    </span>
                    <span class="font-serif-luxury text-xl font-bold tracking-wide text-slate-900">
                        Shaadi <span class="text-[#850625]">Sense</span>
                    </span>
                </div>
                <p class="text-xs md:text-sm text-slate-600 leading-relaxed font-medium">
                    Empowering couples and families with smart, transparent, and seamless event planning. From venue matching to budget split.
                </p>

                <!-- Social Media Icons -->
                <div class="flex items-center space-x-2.5 pt-1">
                    <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" aria-label="Instagram" class="w-8.5 h-8.5 rounded-lg bg-rose-50 hover:bg-[#850625] text-slate-600 hover:text-white border border-rose-100 flex items-center justify-center transition-all text-xs shadow-xs"><i class="fab fa-instagram"></i></a>
                    <a href="https://x.com/" target="_blank" rel="noopener noreferrer" aria-label="X" class="w-8.5 h-8.5 rounded-lg bg-rose-50 hover:bg-[#850625] text-slate-600 hover:text-white border border-rose-100 flex items-center justify-center transition-all text-xs shadow-xs"><i class="fab fa-twitter"></i></a>
                    <a href="https://www.linkedin.com/" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn" class="w-8.5 h-8.5 rounded-lg bg-rose-50 hover:bg-[#850625] text-slate-600 hover:text-white border border-rose-100 flex items-center justify-center transition-all text-xs shadow-xs"><i class="fab fa-linkedin-in"></i></a>
                    <a href="https://www.youtube.com/" target="_blank" rel="noopener noreferrer" aria-label="YouTube" class="w-8.5 h-8.5 rounded-lg bg-rose-50 hover:bg-[#850625] text-slate-600 hover:text-white border border-rose-100 flex items-center justify-center transition-all text-xs shadow-xs"><i class="fab fa-youtube"></i></a>
                </div>
            </div>

            <!-- Column 2: Solutions / Services (3 Cols) -->
            <div class="md:col-span-3 space-y-3">
                <h4 class="text-slate-900 font-bold text-xs uppercase tracking-wider">Solutions</h4>
                <ul class="space-y-2 text-xs md:text-sm text-slate-600 font-medium">
                    <li><a href="<?php echo e(route('home')); ?>#categories" class="hover:text-[#850625] transition-colors">Event Categories</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#estimator" class="hover:text-[#850625] transition-colors">Smart Cost Estimator</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#how-it-works" class="hover:text-[#850625] transition-colors">AI Vendor Matchmaker</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#why-choose-us" class="hover:text-[#850625] transition-colors">Budget Allocation</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#testimonials" class="hover:text-[#850625] transition-colors">Client Reviews</a></li>
                </ul>
            </div>

            <!-- Column 3: Resources (3 Cols) -->
            <div class="md:col-span-3 space-y-3">
                <h4 class="text-slate-900 font-bold text-xs uppercase tracking-wider">Resources</h4>
                <ul class="space-y-2 text-xs md:text-sm text-slate-600 font-medium">
                    <li><a href="<?php echo e(route('home')); ?>#how-it-works" class="hover:text-[#850625] transition-colors">Wedding Planning Guide</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#estimator" class="hover:text-[#850625] transition-colors">Vendor Pricing Index</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#shaadi-experience-zone" class="hover:text-[#850625] transition-colors">Blog & Inspiration</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#estimator" class="hover:text-[#850625] transition-colors">Budget Calculators</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#testimonials" class="hover:text-[#850625] transition-colors">Community Forum</a></li>
                </ul>
            </div>

            <!-- Column 4: Company (2 Cols) -->
            <div class="md:col-span-2 space-y-3">
                <h4 class="text-slate-900 font-bold text-xs uppercase tracking-wider">Company</h4>
                <ul class="space-y-2 text-xs md:text-sm text-slate-600 font-medium">
                    <li><a href="<?php echo e(route('home')); ?>#why-choose-us" class="hover:text-[#850625] transition-colors">About Us</a></li>
                    <li><a href="<?php echo e(route('home')); ?>#how-it-works" class="hover:text-[#850625] transition-colors">How It Works</a></li>
                    <li><a href="mailto:support@shaadisense.com" class="hover:text-[#850625] transition-colors">Contact Support</a></li>
                    <li><a href="<?php echo e(route('admin.login')); ?>" class="hover:text-[#850625] transition-colors flex items-center gap-1.5"><i class="fa-solid fa-lock text-[10px] text-[#850625]"></i> Admin Login</a></li>
                </ul>
            </div>
        </div>

        <!-- BOTTOM COPYRIGHT & LEGAL LINKS (Ref Image 2 Bottom Bar) -->
        <div class="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-medium pt-2">
            <p>&copy; <?php echo e(date('Y')); ?> Shaadi Sense Inc. All rights reserved.</p>
            <div class="flex flex-wrap items-center gap-6">
                <a href="<?php echo e(route('home')); ?>#site-footer" class="hover:text-slate-900 transition-colors">Terms of Service</a>
                <a href="<?php echo e(route('home')); ?>#site-footer" class="hover:text-slate-900 transition-colors">Privacy Policy</a>
                <a href="<?php echo e(route('home')); ?>#site-footer" class="hover:text-slate-900 transition-colors">Cookie Settings</a>
                <a href="<?php echo e(route('home')); ?>#site-footer" class="hover:text-slate-900 transition-colors">Accessibility</a>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\event_planner\resources\views/web/partials/footer.blade.php ENDPATH**/ ?>