<?php $__currentLoopData = collect($plannerSteps)->where('renderer', 'generic'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $isMultiple = in_array($step['type'], ['checkbox', 'multi_select'], true);
        $hasOptions = count($step['options']) > 0;
    ?>
    <div x-show="currentStep === <?php echo e($step['number']); ?>" x-transition:enter="transition ease-out duration-300 transform" x-transition:enter-start="opacity-0 translate-y-4" x-transition:enter-end="opacity-100 translate-y-0" class="space-y-8">
        <div class="space-y-2">
            <div class="inline-flex items-center gap-2 rounded-full bg-[#850625]/10 px-3 py-1 text-xs font-extrabold uppercase tracking-widest text-[#850625]">
                <i class="fa-solid fa-clipboard-question text-[10px]"></i>
                <span>Step <?php echo e(str_pad((string) $step['number'], 2, '0', STR_PAD_LEFT)); ?> / <?php echo e(count($plannerSteps)); ?> • <?php echo e($step['name']); ?></span>
            </div>
            <h2 class="text-3xl font-extrabold font-serif-luxury text-slate-900 sm:text-4xl"><?php echo e($step['question']); ?></h2>
            <p class="text-sm text-slate-600 sm:text-base"><?php echo e($isMultiple ? 'Select all options that apply.' : 'Choose the option that best matches your event.'); ?></p>
        </div>

        <?php if($hasOptions): ?>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                <?php $__currentLoopData = $step['option_details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $optionIndex => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $optionValue = (string) $option['value'];
                        $optionImage = $option['image'] ?? null;
                    ?>
                    <button type="button"
                        @click="selectGenericOption(<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($optionValue)->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($isMultiple)->toHtml() ?>)"
                        :aria-pressed="isGenericSelected(<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($optionValue)->toHtml() ?>)"
                        :class="isGenericSelected(<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($optionValue)->toHtml() ?>) ? 'border-[#850625] ring-2 ring-[#850625]/20 shadow-xl' : 'border-slate-200 bg-white hover:border-rose-200 hover:shadow-md'"
                        class="group relative min-h-[170px] overflow-hidden rounded-3xl border-2 bg-white p-5 text-left text-slate-900 transition-all">
                        <?php if($optionImage): ?>
                            <span class="absolute inset-0 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                                :class="isGenericSelected(<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($optionValue)->toHtml() ?>) ? '!opacity-100' : ''">
                                <img src="<?php echo e($optionImage); ?>" alt="<?php echo e($option['title']); ?>" class="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105">
                                <span class="absolute inset-0 bg-gradient-to-t from-white via-white/65 to-white/5"></span>
                            </span>
                        <?php endif; ?>
                        <span class="relative z-10 flex h-full min-h-[128px] flex-col justify-between gap-5">
                            <span class="flex items-center justify-between gap-3">
                                <span class="flex h-11 w-11 items-center justify-center rounded-2xl border border-white/60 bg-rose-50/90 text-[#850625] shadow-sm backdrop-blur-sm"><i class="<?php echo e($option['icon']); ?> text-lg"></i></span>
                                <span x-show="isGenericSelected(<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>, <?php echo \Illuminate\Support\Js::from($optionValue)->toHtml() ?>)" class="rounded-full bg-[#850625] px-2.5 py-1 text-[10px] font-extrabold text-white"><i class="fa-solid fa-circle-check mr-1"></i>Selected</span>
                            </span>
                            <span class="space-y-1">
                                <strong class="block text-base leading-snug text-slate-950 sm:text-lg"><?php echo e($option['title']); ?></strong>
                                <span class="block text-xs font-medium leading-relaxed text-[#850625]"><?php echo e($option['subtitle']); ?></span>
                            </span>
                        </span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php elseif($step['type'] === 'number'): ?>
            <label class="block rounded-3xl border border-rose-100 bg-white p-6 shadow-lg">
                <span class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-600">Your answer</span>
                <input type="number" x-model.number="dynamicAnswers[<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>]" placeholder="<?php echo e($step['placeholder'] ?: 'Enter a number'); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-[#850625] focus:ring-2 focus:ring-[#850625]/10">
            </label>
        <?php else: ?>
            <label class="block rounded-3xl border border-rose-100 bg-white p-6 shadow-lg">
                <span class="mb-2 block text-xs font-bold uppercase tracking-wider text-slate-600">Your answer</span>
                <textarea x-model="dynamicAnswers[<?php echo \Illuminate\Support\Js::from($step['code'])->toHtml() ?>]" rows="4" maxlength="2000" placeholder="<?php echo e($step['placeholder'] ?: 'Type your answer'); ?>" class="w-full rounded-xl border border-slate-200 px-4 py-3 text-sm font-semibold outline-none focus:border-[#850625] focus:ring-2 focus:ring-[#850625]/10"></textarea>
            </label>
        <?php endif; ?>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\event_planner\resources\views/ai-planner/steps/generic-question.blade.php ENDPATH**/ ?>