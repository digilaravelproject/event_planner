@php
    $value = is_bool($status) ? ($status ? 'active' : 'inactive') : strtolower((string) $status);
    $classes = match($value) { 'active','enabled','sent','success','resolved' => 'bg-emerald-50 text-emerald-700 ring-emerald-200', 'inactive','disabled','rejected' => 'bg-rose-50 text-rose-700 ring-rose-200', 'pending','scheduled','warning' => 'bg-amber-50 text-amber-700 ring-amber-200', default => 'bg-slate-100 text-slate-600 ring-slate-200' };
@endphp
<span class="inline-flex rounded-full px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide ring-1 {{ $classes }}">{{ ucfirst($value) }}</span>
